Web Applications (using iPhone's Add to HomePage command from the web application).
Configure this in your login.html and index.html files.
64x64:   iPhone Icon via apple-touch-icon-precomposed 
240x360: iPhone Splash Screen via apple-touch-startup-image 

ICONS
57x57:   iPhone Icon
72x72:   iPhone Retina Icon
114x114: iPad Icon
144x144: iPad Retina Icon
