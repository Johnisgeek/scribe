var _WM_APP_PROPERTIES = {
  "activeTheme" : "mobile",
  "dateFormat" : "",
  "defaultLanguage" : "en",
  "displayName" : "Scribe",
  "homePage" : "Main",
  "name" : "Scribe",
  "platformType" : "MOBILE",
  "supportedLanguages" : "en",
  "timeFormat" : "",
  "type" : "APPLICATION",
  "version" : "1.0"
};