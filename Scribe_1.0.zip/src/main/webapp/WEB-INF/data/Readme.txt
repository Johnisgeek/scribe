This data directory is for HSQLDB Databases.

You can also add your own HSQLDB database or other data files to this directory.
All HSQLDB databases must be in this directory.
